import UIKit

let firstName = "Steven"
var lastName: String? = "Jobs"

print("Nome: \(firstName) \(lastName ?? "Wozniak")")

if let lastName = lastName {
     print("O nome completo é \(firstName) \(lastName).")
} else {
    print("Error")
}
